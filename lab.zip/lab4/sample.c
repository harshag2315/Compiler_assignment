#include <stdio.h>
int main() {
    int a, b, sum;
    float avg;
    sum = a + b;
    return 0;
}
